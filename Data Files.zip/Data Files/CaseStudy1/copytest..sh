cp /home/student/fscoll/*.xml /home/student/fsarchive/*.xml
cp /home/student/fscoll/*.xml /home/student/fsprocess/*.xml