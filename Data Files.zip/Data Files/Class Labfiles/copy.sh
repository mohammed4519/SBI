cp /home/student/fscoll/Trigger.xml /home/student/fsext/Trigger1.xml

